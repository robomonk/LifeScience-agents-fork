# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deployment script for the Drug Discovery Agent (DEBUGGER MODE)."""

import os
import vertexai
from absl import app, flags
from dotenv import load_dotenv
from vertexai import agent_engines
import traceback

FLAGS = flags.FLAGS
flags.DEFINE_string("project_id", None, "GCP project ID.")
flags.DEFINE_string("location", None, "GCP location.")
flags.DEFINE_string("bucket", None, "GCP storage bucket for staging.")
flags.DEFINE_string("resource_id", None, "Agent Engine resource ID for deletion.")
flags.DEFINE_bool("create", False, "Creates a new agent.")
flags.DEFINE_bool("delete", False, "Deletes an existing agent.")
flags.DEFINE_bool("list", False, "Lists all agents.")
flags.mark_bool_flags_as_mutual_exclusive(["create", "delete", "list"])

# Global variable to hold the agent once initialized
_CACHED_AGENT = None

class DrugDiscoveryDebugEngine:
    def __init__(self):
        print("Debug Engine Initialized")

    async def query(self, input: str) -> str:
        """
        INTERACTIVE DEBUGGER.
        Responds to specific keywords to test agent health step-by-step.
        """
        global _CACHED_AGENT
        command = input.lower().strip()

        # TEST 1: Infrastructure Ping
        if command == "ping":
            return "✅ PONG! The Cloud Container is alive and responding."

        # TEST 2: Import Check
        # Tests if we can import the code without crashing
        if command == "import":
            try:
                import drug_discovery_agent.agent
                return "✅ SUCCESS: Code imported successfully (No syntax errors or missing top-level dependencies)."
            except Exception as e:
                return f"❌ IMPORT CRASHED:\n{traceback.format_exc()}"

        # TEST 3: Initialize Agent
        # Tests if we can create the agent object (connect to Vertex, load tools)
        if command == "init":
            try:
                if _CACHED_AGENT:
                    return "ℹ️ Agent was already initialized."
                
                print("Attempting to initialize root_agent...")
                from drug_discovery_agent.agent import root_agent
                _CACHED_AGENT = root_agent
                return "✅ SUCCESS: Agent Object initialized. Tools are ready."
            except Exception as e:
                return f"❌ INITIALIZATION CRASHED:\n{traceback.format_exc()}"

        # TEST 4: Run Agent (The Real Deal)
        # Only runs if you didn't type a command
        try:
            if not _CACHED_AGENT:
                # Lazy load if not explicitly initialized
                from drug_discovery_agent.agent import root_agent
                _CACHED_AGENT = root_agent
            
            response_parts = []
            async for event in _CACHED_AGENT.run_async(input):
                if hasattr(event, 'text') and event.text:
                    response_parts.append(event.text)
                else:
                    response_parts.append(f"\n[Log: {type(event).__name__}] {str(event)}\n")
            
            if not response_parts:
                return "⚠️ Agent ran but produced no output."
            return "".join(response_parts)

        except Exception as e:
            return f"❌ RUNTIME CRASHED:\n{traceback.format_exc()}"


def cleanup_existing_agents(display_name: str):
    print(f"🧹 Checking for existing agents named '{display_name}'...")
    try:
        agents = agent_engines.list()
        for agent in agents:
            if agent.display_name == display_name:
                try:
                    agent.delete(force=True)
                    print("     Deleted old agent.")
                except:
                    pass
    except:
        pass

def create_agent(env_vars):
    AGENT_NAME = "agentic-tx"
    cleanup_existing_agents(AGENT_NAME)

    print(f"🚀 Deploying DEBUGGER AGENT: {AGENT_NAME}...")
    remote_agent = agent_engines.create(
        DrugDiscoveryDebugEngine(),
        display_name=AGENT_NAME,
        requirements=[
            # PINNED VERSIONS (Known Good from Echo Agent)
            "google-cloud-aiplatform==1.131.0",
            "pydantic==2.11.7",
            "cloudpickle==3.1.1",
            
            # Agent Deps
            "google-adk>=1.18.0",
            "google-search-results>=2.4.2",
            "requests>=2.0.0",
            "python-dotenv>=1.0.1",
            "biopython>=1.83",
            "pubchempy>=1.0.4",
        ],
        extra_packages=["./drug_discovery_agent"],
        env_vars=env_vars
    )
    print(f"✅ Created remote agent: {remote_agent.resource_name}")

def main(_):
    load_dotenv()
    env_vars = {}
    
    # Load env vars
    keys = ["TXGEMMA_PREDICT_ENDPOINT_ID", "TXGEMMA_CHAT_ENDPOINT_ID", "ENTREZ_EMAIL", "GOOGLE_GENAI_USE_VERTEXAI"]
    for k in keys:
        env_vars[k] = os.getenv(k)

    project_id = FLAGS.project_id or os.getenv("GOOGLE_CLOUD_PROJECT")
    location = FLAGS.location or os.getenv("GOOGLE_CLOUD_LOCATION")
    bucket = FLAGS.bucket or os.getenv("GOOGLE_CLOUD_STORAGE_BUCKET")

    vertexai.init(project=project_id, location=location, staging_bucket=f"gs://{bucket}")

    if FLAGS.create:
        create_agent(env_vars)

if __name__ == "__main__":
    app.run(main)