# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deployment script for the Drug Discovery Agent (Monolith Version)."""

import os
import vertexai
from absl import app, flags
from dotenv import load_dotenv
from vertexai import agent_engines
from vertexai.preview import reasoning_engines

# --- DEFINE THE AGENT LOGIC DIRECTLY HERE ---
# This bypasses import errors from your local package structure.

class DrugDiscoveryAgent:
    def __init__(self, project: str, location: str, model: str):
        self.model_name = model
        self.project = project
        self.location = location
        print(f"Agent Initialized for {project} in {location}")

    def search_pubchem(self, compound_name: str) -> str:
        """Searches PubChem for a compound (Mocked for stability)."""
        # In a real monolith, we'd paste the full tool code here.
        # For this test, we verify the Cloud Agent *can* run logic.
        return f"PubChem Search Result for {compound_name}: [CID: 2244] Aspirin (Acetylsalicylic Acid)"

    def query(self, input: str) -> str:
        """
        The entry point for the Reasoning Engine.
        """
        # Simple logic to prove it runs
        if "aspirin" in input.lower():
            data = self.search_pubchem("aspirin")
            return f"Found compound data: {data}. It is a common NSAID."
        
        return f"I received your query: '{input}'. My logic is running on Vertex AI!"

# --- DEPLOYMENT CONFIG ---

FLAGS = flags.FLAGS
flags.DEFINE_string("project_id", None, "GCP project ID.")
flags.DEFINE_string("location", None, "GCP location.")
flags.DEFINE_string("bucket", None, "GCP storage bucket for staging.")
flags.DEFINE_bool("create", False, "Creates a new agent.")
flags.DEFINE_bool("list", False, "Lists all agents.")

def create_agent():
    AGENT_NAME = "agentic-tx"
    
    # 1. Cleanup
    try:
        agents = agent_engines.list()
        for agent in agents:
            if agent.display_name == AGENT_NAME:
                print(f"Deleting old agent: {agent.resource_name}")
                agent.delete(force=True)
    except:
        pass

    # 2. Deploy
    print(f"🚀 Deploying MONOLITH AGENT: {AGENT_NAME}...")
    
    # We pass configuration to the class constructor
    agent_instance = DrugDiscoveryAgent(
        project=os.getenv("GOOGLE_CLOUD_PROJECT"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION"),
        model="gemini-1.5-pro-002"
    )

    remote_agent = agent_engines.create(
        agent_instance,
        display_name=AGENT_NAME,
        requirements=[
            # CRITICAL PINNED VERSIONS
            "google-cloud-aiplatform==1.131.0",
            "pydantic==2.11.7",
            "cloudpickle==3.1.1",
        ],
    )
    print(f"✅ Created remote agent: {remote_agent.resource_name}")

def main(_):
    load_dotenv()
    project_id = os.getenv("GOOGLE_CLOUD_PROJECT")
    location = os.getenv("GOOGLE_CLOUD_LOCATION")
    bucket = os.getenv("GOOGLE_CLOUD_STORAGE_BUCKET")
    
    vertexai.init(project=project_id, location=location, staging_bucket=f"gs://{bucket}")

    if FLAGS.create:
        create_agent()

if __name__ == "__main__":
    app.run(main)